/* Draft store. Never reuse health-product payment links for cruise products.
   Launch only after PDFs, product-specific checkout URLs, seller details,
   delivery, privacy and refund terms are finalized. Update all preview copy
   and remove preview notices only after verifying the complete purchase flow. */
window.CRUISE_STORE = {
  live: false,
  checkoutUrls: {bundle: '', cabin: '', health: '', spending: '', port: ''}
};
